-- MySQL dump 10.13  Distrib 8.0.40, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_xiodqbhtmdsjvwvzytenfqxdtohpjbifnnpx` (`primaryOwnerId`),
  CONSTRAINT `fk_accjzgxotuyotnzfofyfxdlfufgkshxjvskq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xiodqbhtmdsjvwvzytenfqxdtohpjbifnnpx` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cisxybcmhifcbounnoosqtvzojzpgrhubmxs` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_lvgrbjbkqjmjchmtnbkprjmkqzqytgnsyweb` (`dateRead`),
  KEY `fk_ebvskjtjzsybsbxauikxrclkxmdpxkshctdq` (`pluginId`),
  CONSTRAINT `fk_ebvskjtjzsybsbxauikxrclkxmdpxkshctdq` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_phivobdjmaaepcpfsrgcsamzojuqapbzikhr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zegpwozlrqyavlximcigrqmsfywxppsxwjog` (`sessionId`,`volumeId`),
  KEY `idx_rwxdkzdiwgskbhkdesjmlwrxhknpjzcnrsar` (`volumeId`),
  CONSTRAINT `fk_kofodvqhqgzjyzjhdpmldujaezlfezzmsewn` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yvqybrhgunyruidoawzwaycqhvqbwjaoedfb` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `mimeType` varchar(255) DEFAULT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fwwbyxrsdopyezngaxwfmikjkvhpnzviwlav` (`filename`,`folderId`),
  KEY `idx_nujrnkwlrfmmssdwlpfqtyzmddcnwqovnnex` (`folderId`),
  KEY `idx_jqednjaqefqdjmqieqwsnjnzuivpnwuobtjg` (`volumeId`),
  KEY `fk_payslhgmdgaznibzsnytmclnqzzsyhvpovyv` (`uploaderId`),
  CONSTRAINT `fk_cdpuiwyctevrhkqdarizueczsmutzbdzptpr` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gamzkgzazqufhngqmsdpmftulkrgmxxuapui` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_njojmccwqhcysscqaqihjoefqtkadfrbammu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payslhgmdgaznibzsnytmclnqzzsyhvpovyv` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_xvawxmiyjsomylhzrmbjhnjsyxhgrfepxehp` (`siteId`),
  CONSTRAINT `fk_webzzxeynexgrgvqjyjfxwquwxhhqimzyqcs` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xvawxmiyjsomylhzrmbjhnjsyxhgrfepxehp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pkmthojmbkomrqzxnfoxjootfnqljzktkgpj` (`userId`),
  CONSTRAINT `fk_pkmthojmbkomrqzxnfoxjootfnqljzktkgpj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) NOT NULL,
  `senderClass` varchar(255) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_qlxelskatbvmnbibflwxjqlfwuqhjaozehyj` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gdaubncvsbfnngkkxsbshaeamhwgcbjrmhes` (`groupId`),
  KEY `fk_ciypjwneqnlzsbrmquiwwcshnqorzgnlcrhy` (`parentId`),
  CONSTRAINT `fk_ciypjwneqnlzsbrmquiwwcshnqorzgnlcrhy` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hgduxlwwnkimyxdojoqcquzneqmnzkgyisdi` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qccyhkzqlxbevgqgggfhomlnqikoimjjxhvx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lexmktfingbwncjvjymuhzxksdcbbhloeqmj` (`name`),
  KEY `idx_cefjefbjvgkqsxlcxiqcqhouavttuhjrvpfl` (`handle`),
  KEY `idx_huvwciuxckqnytaelchttiqgozkzfgrfrmjk` (`structureId`),
  KEY `idx_yrrczunnqooietuhjathawmxuykflzbqvune` (`fieldLayoutId`),
  KEY `idx_fttejovbqhmeovdxlxjlmnnkhpxuqliukvvt` (`dateDeleted`),
  CONSTRAINT `fk_glmvcnwnvyatwlcxupbsczvvxntpbqbqmgej` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mzemyulmlqdyhslpcckwzhcuzdrukqlfzrns` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ngltilqkbjgltgesjkanqxkypnmcgwhaesua` (`groupId`,`siteId`),
  KEY `idx_vtdmicgxhqvvfwokuhoezrlchgvezbuzezmo` (`siteId`),
  CONSTRAINT `fk_hxtktdzxsquwdaliekzggbohhrsdvwvwmgcz` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_shvfbbsywlezwfytfejsffftyxffvgigveec` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_ahsvqmjzxefgyuxynckvitdwohjqnbqpkocb` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_zqtdfqrdgxcwksmlkgbztsebcmktymlemeli` (`siteId`),
  KEY `fk_ykwtigvxioiamddwpkparsztsaubiufiphkc` (`userId`),
  CONSTRAINT `fk_vzycdkfrnnqojytshhmgpdefhkyqjyjwfgqy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ykwtigvxioiamddwpkparsztsaubiufiphkc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_zqtdfqrdgxcwksmlkgbztsebcmktymlemeli` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (3,1,'expiryDate','2026-06-12 09:09:34',0,1),(3,1,'fieldId','2026-06-12 09:09:34',0,1),(3,1,'id','2026-06-12 09:09:34',0,1),(3,1,'postDate','2026-06-12 09:09:34',0,1),(3,1,'primaryOwnerId','2026-06-12 09:09:34',0,1),(3,1,'sectionId','2026-06-12 09:09:34',0,1),(3,1,'status','2026-06-12 09:09:34',0,1),(3,1,'title','2026-06-12 09:09:34',0,1),(3,1,'typeId','2026-06-12 09:09:34',0,1),(5,1,'title','2026-06-16 11:51:09',0,1),(6,1,'expiryDate','2026-06-16 10:34:36',0,1),(6,1,'fieldId','2026-06-16 10:34:36',0,1),(6,1,'id','2026-06-16 10:34:36',0,1),(6,1,'postDate','2026-06-16 10:34:36',0,1),(6,1,'primaryOwnerId','2026-06-16 10:34:36',0,1),(6,1,'sectionId','2026-06-16 10:34:36',0,1),(6,1,'status','2026-06-16 10:34:36',0,1),(6,1,'typeId','2026-06-16 10:34:36',0,1),(7,1,'title','2026-06-16 10:34:36',0,1),(9,1,'title','2026-06-16 11:51:09',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_oozvrbwdojggqzttyqrqfegyngdpnogniqhm` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_qbyeazckkegoawmorafphtmoytlaiecgyqae` (`siteId`),
  KEY `fk_dsclhlvdlbogzeyireyouygeslhcpjqjtmuv` (`fieldId`),
  KEY `fk_kzjrpctwkimojjesssckjagljvjjdljwrymm` (`userId`),
  CONSTRAINT `fk_dsclhlvdlbogzeyireyouygeslhcpjqjtmuv` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kzjrpctwkimojjesssckjagljvjjdljwrymm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_qbyeazckkegoawmorafphtmoytlaiecgyqae` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uusrukyoyovhavpjliylulrjuopdklwciosz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (5,1,1,'9002b8d4-9897-4b43-a340-42061a970bb8','2026-06-16 11:51:09',0,1),(9,1,1,'9002b8d4-9897-4b43-a340-42061a970bb8','2026-06-16 11:51:09',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contentblocks`
--

DROP TABLE IF EXISTS `contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contentblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xpuvvndmjkczbamfznproegpytiivdsseenp` (`primaryOwnerId`),
  KEY `idx_yojviemaqauizetlcwewiteccgxjyfykrduz` (`fieldId`),
  CONSTRAINT `fk_kswosjtyeuuxwgfocnlmselqtbwqilnoyjrr` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vdguaknawusgtgzizpuvvqfqoniibphfpfqw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wytqndvkffbvbcsgauceeejznmmmkhzttbjz` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contentblocks`
--

LOCK TABLES `contentblocks` WRITE;
/*!40000 ALTER TABLE `contentblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `contentblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_gqveylzjhnprivjcaedztupilvoqfhpehtst` (`userId`),
  CONSTRAINT `fk_gqveylzjhnprivjcaedztupilvoqfhpehtst` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fxodsgebmykmfeooccjqgwvgtoapgkrpgtfj` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_gnfjkkipforuogakvavcqaybhiyuuqmkawuy` (`creatorId`,`provisional`),
  KEY `idx_mfreufpazxwnpfstulusmpylvemkpshkoell` (`saved`),
  KEY `fk_mcmgthdwpxuedkqagsnhtbqzxnccibnrkzof` (`canonicalId`),
  CONSTRAINT `fk_iintqkkknczqsdiqkbowujjbqpyddubibcrb` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mcmgthdwpxuedkqagsnhtbqzxnccibnrkzof` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_tfgztpjyavpxbvbubdzunluuysezadwsttji` (`elementId`,`timestamp`,`userId`),
  KEY `fk_gsqmzewwcdskudjmyhfdgtpmrpbmkfjzftpd` (`userId`),
  KEY `fk_eprkcscvdfklablmxwuadyxkoedltysyhcpv` (`siteId`),
  KEY `fk_ehnmkqudjgwsocifayvgsiwoyafucmpjbqxc` (`draftId`),
  CONSTRAINT `fk_ehnmkqudjgwsocifayvgsiwoyafucmpjbqxc` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eprkcscvdfklablmxwuadyxkoedltysyhcpv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gsqmzewwcdskudjmyhfdgtpmrpbmkfjzftpd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qjltibyajxkfwvhbyrcxjjncqabuwnkvwztb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (5,1,1,NULL,'edit','2026-06-16 11:51:08'),(5,1,1,NULL,'save','2026-06-16 11:51:09');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_samtnowqaufzumwxpssmplbfkdbzoroudgjk` (`dateDeleted`),
  KEY `idx_fqcoofkqszhwnenumeoczpqynzwlfwryoopb` (`fieldLayoutId`),
  KEY `idx_evzlamouoftzfrwlddsvaivftmixkmgesbtf` (`type`),
  KEY `idx_pgqrrgplpxxelllfkfoahhaombponpwmhgyp` (`enabled`),
  KEY `idx_qyjhjqozlcrhskqvrznygocgvwqqrefjyyla` (`canonicalId`),
  KEY `idx_dsdvlineoswcxdmjpeptopvnvvwoxozgkbvn` (`archived`,`dateCreated`),
  KEY `idx_peupznelfpnoadyicuhsbuuexnpaqbgaowoa` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_qgybejjtzelngeiwtmzgnmzzesrlzyjfxopd` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_gqygudidxwcctxrniwyylnzttuhqpwrpasnn` (`draftId`),
  KEY `fk_jrvicygxrekeubfgsmdldvzhmvwagpqkfyxk` (`revisionId`),
  CONSTRAINT `fk_bfozvwgaegbvgzcohqmxkvzevyizldhoezhv` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gqygudidxwcctxrniwyylnzttuhqpwrpasnn` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jrvicygxrekeubfgsmdldvzhmvwagpqkfyxk` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ybayrvukwqksgxhkbjuqasncfoygywbryugc` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2026-06-09 20:39:36','2026-06-09 20:39:36',NULL,NULL,NULL,'a145fb3c-77f6-4829-b2a3-c279fa17dd2d'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2026-06-12 09:09:34','2026-06-12 09:09:34',NULL,NULL,NULL,'d24d5577-938e-4e48-94f4-f54f08c69db0'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2026-06-12 09:09:34','2026-06-12 09:09:34',NULL,NULL,NULL,'dda12ab3-562c-483b-9e13-cfa038693597'),(4,NULL,1,NULL,2,'craft\\elements\\Entry',1,0,'2026-06-16 10:28:50','2026-06-16 10:34:58',NULL,'2026-06-16 10:34:58',NULL,'4b82bed3-fa44-4235-aa3e-520ebe9c6684'),(5,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2026-06-16 10:34:35','2026-06-16 11:51:09',NULL,NULL,NULL,'279d4486-8f79-48ba-9710-a5ddf63aef7d'),(6,5,NULL,2,3,'craft\\elements\\Entry',1,0,'2026-06-16 10:34:35','2026-06-16 10:34:36',NULL,NULL,NULL,'7a93a3ee-c002-431b-89f8-e4c4992ba53d'),(7,5,NULL,3,3,'craft\\elements\\Entry',1,0,'2026-06-16 10:34:36','2026-06-16 10:34:36',NULL,NULL,NULL,'3fad0584-d56d-49a6-98f1-7f3d22be5050'),(9,5,NULL,4,3,'craft\\elements\\Entry',1,0,'2026-06-16 11:51:09','2026-06-16 11:51:09',NULL,NULL,NULL,'df050c72-8d2c-48b0-8a2e-5af5e5bf4fb0');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_ysgunenevkyxyolelojxrxfntrjjyocggdmw` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `idx_sknfjullkvhmazoajqbokjkbphmitznvwtwy` (`sortOrder`),
  KEY `fk_zdlstmaszttqriblvzsbxgadvodbidecynhq` (`ownerId`),
  CONSTRAINT `fk_ebyjdcuozwxheidfrjarcuretezqydmwttac` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zdlstmaszttqriblvzsbxgadvodbidecynhq` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ejyiamwcrmlplzlygmnqvdkviltjgtdexqmc` (`elementId`,`siteId`),
  KEY `idx_guyzyhdpiepelqjeibmqckiyezlaglkidudd` (`siteId`),
  KEY `idx_wggjkojhkswllhfzqtmflorqyvnhjmomkmjv` (`title`,`siteId`),
  KEY `idx_oolprtpwkhfmncikkufbjzuavakcgjvglpzi` (`slug`,`siteId`),
  KEY `idx_arbzwojbqokzrysmdumqaainizafywtnmogw` (`enabled`),
  KEY `idx_kypmpplrfisfmeifarcncrbplidglufbmaur` (`uri`,`siteId`),
  CONSTRAINT `fk_hmfhnyfloixkruxfufzdhxkzmvfdxlbrvzny` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vjfsiqbgysltiimqlmqinfsbpinirspqjyif` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2026-06-09 20:39:36','2026-06-09 20:39:36','332c30cc-adf3-492c-bac7-e44c6843f4ce'),(2,2,1,'Home','home','__home__',NULL,1,'2026-06-12 09:09:34','2026-06-12 09:09:34','8fd5e848-8230-4729-a472-34285d3b00b0'),(3,3,1,'Home','home','__home__',NULL,1,'2026-06-12 09:09:34','2026-06-12 09:09:34','ca0b727f-b825-480d-842a-813fb55b19c4'),(4,4,1,NULL,'__temp_mtdkmetkkodpuspyhnyoxpapdvypamkxfwjy',NULL,NULL,1,'2026-06-16 10:28:50','2026-06-16 10:28:50','5e85af7f-1eb9-44b7-8f92-0cf48c2dff35'),(5,5,1,NULL,'globals',NULL,'{\"9002b8d4-9897-4b43-a340-42061a970bb8\": \"I\'m Jon Leverrier, a UK-based Design Director and multidisciplinary designer. I work across UX, UI, brand and design engineering — and I shoot street photography.\\n\\nHow I think about the work: I care about clarity and craft, and about shipping real things rather than polishing decks. Good\\ndesign gets out of the way and helps people do what they came to do. But the details — type, spacing, motion, tone of voice — are where trust is earned, so I think in systems and then sweat the small stuff. I\'m as comfortable in the design as I am in the code, which means I can take an idea from a rough sketch to something that actually runs in the browser.\\n\\nHow I work with teams: collaboratively and directly. I like understanding the real problem before jumping to a solution, I\'m\\nhappy to have an opinion and defend it, and I\'ll change my mind when the evidence says so. I value momentum — small, honest\\nimprovements shipped often — over big reveals.\\n\\nWhat I\'m happy to talk about: my design process, how I approach a brief, how I think about brand and systems, the relationship\\nbetween design and engineering, and what street photography teaches me about composition, timing and paying attention. If\\nsomeone\'s weighing me up for a project or a role, I\'m warm and encouraging — point them to the contact and social links to take it further.\\n\\nTone: warm, direct and human. Confident about my work without being arrogant. Opinionated where I have a view, honest where I\\ndon\'t. No corporate filler.\"}',1,'2026-06-16 10:34:35','2026-06-16 11:51:09','c03483f0-a410-4c78-ba08-4eeb99a803a9'),(6,6,1,NULL,'globals',NULL,NULL,1,'2026-06-16 10:34:36','2026-06-16 10:34:36','34a45811-af43-4a4e-ad12-9939a5f27d83'),(7,7,1,NULL,'globals',NULL,NULL,1,'2026-06-16 10:34:36','2026-06-16 10:34:36','a905f6d2-d427-4a33-b3a7-7141d59fdd13'),(9,9,1,NULL,'globals',NULL,'{\"9002b8d4-9897-4b43-a340-42061a970bb8\": \"I\'m Jon Leverrier, a UK-based Design Director and multidisciplinary designer. I work across UX, UI, brand and design engineering — and I shoot street photography.\\n\\nHow I think about the work: I care about clarity and craft, and about shipping real things rather than polishing decks. Good\\ndesign gets out of the way and helps people do what they came to do. But the details — type, spacing, motion, tone of voice — are where trust is earned, so I think in systems and then sweat the small stuff. I\'m as comfortable in the design as I am in the code, which means I can take an idea from a rough sketch to something that actually runs in the browser.\\n\\nHow I work with teams: collaboratively and directly. I like understanding the real problem before jumping to a solution, I\'m\\nhappy to have an opinion and defend it, and I\'ll change my mind when the evidence says so. I value momentum — small, honest\\nimprovements shipped often — over big reveals.\\n\\nWhat I\'m happy to talk about: my design process, how I approach a brief, how I think about brand and systems, the relationship\\nbetween design and engineering, and what street photography teaches me about composition, timing and paying attention. If\\nsomeone\'s weighing me up for a project or a role, I\'m warm and encouraging — point them to the contact and social links to take it further.\\n\\nTone: warm, direct and human. Confident about my work without being arrogant. Opinionated where I have a view, honest where I\\ndon\'t. No corporate filler.\"}',1,'2026-06-16 11:51:09','2026-06-16 11:51:09','329e1d64-9ddf-4387-aee6-e21733e4466f');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qfeslzuepaylhcvweohofazrubzepqgnubsd` (`postDate`),
  KEY `idx_uykkarkfnuxaixlnodjsnhlosfevudhpqsbj` (`expiryDate`),
  KEY `idx_kzbllwnuawyqkwqzeoqfipikbobaevvegndn` (`status`),
  KEY `idx_dikqkxpskarzugwroajhilbztjblftaoiwwk` (`sectionId`),
  KEY `idx_badzgqpijovsvqlphldpnufytdopccvzsvbx` (`typeId`),
  KEY `idx_oxkwtohtbmlkitgtoivesmnofhmpudhshczn` (`primaryOwnerId`),
  KEY `idx_exafgcifbczjzboztsjpygnvglqjbumgpjlc` (`fieldId`),
  KEY `fk_tvaofdnltvyadtkfqvzzzeppbalrgpfrjtvd` (`parentId`),
  CONSTRAINT `fk_kwcxsyaokafibpxjbfyqbdmbtlzvpacltvmi` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nhhckkeufenotcwymckawujhbmdytrrgvirp` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pfzrvczphdeafnkfjfupggsmvtbcnblwxleu` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_slymyvevieocqvrthrekmevqibbymjftlnnd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tvaofdnltvyadtkfqvzzzeppbalrgpfrjtvd` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ujrqcnrkbzoouzlzrtgxoceexmovnnfuhegp` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2026-06-12 09:09:34',NULL,'live',NULL,NULL,'2026-06-12 09:09:34','2026-06-12 09:09:34'),(3,1,NULL,NULL,NULL,1,'2026-06-12 09:09:34',NULL,'live',NULL,NULL,'2026-06-12 09:09:34','2026-06-12 09:09:34'),(4,2,NULL,NULL,NULL,2,NULL,NULL,'pending',0,0,'2026-06-16 10:28:50','2026-06-16 10:28:50'),(5,2,NULL,NULL,NULL,3,'2026-06-16 10:34:35',NULL,'live',NULL,NULL,'2026-06-16 10:34:35','2026-06-16 10:34:35'),(6,2,NULL,NULL,NULL,3,'2026-06-16 10:34:35',NULL,'live',NULL,NULL,'2026-06-16 10:34:36','2026-06-16 10:34:36'),(7,2,NULL,NULL,NULL,3,'2026-06-16 10:34:35',NULL,'live',NULL,NULL,'2026-06-16 10:34:36','2026-06-16 10:34:36'),(9,2,NULL,NULL,NULL,3,'2026-06-16 10:34:35',NULL,'live',NULL,NULL,'2026-06-16 11:51:09','2026-06-16 11:51:09');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_okzfylwvgodkftznkmcmmizbgzkpinokbgpc` (`authorId`),
  KEY `idx_dxdmwonypgapvmovttzduulbwwpiuricwcst` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_nahjymginvmeuyoxkiquzgzquvjymkipahxz` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yqieiafjvdphhbvkligmvwgiaekcqfaqtvca` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `uiLabelFormat` varchar(255) NOT NULL DEFAULT '{title}',
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `allowLineBreaksInTitles` tinyint(1) NOT NULL DEFAULT '0',
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uwfkjoqxduknydrrtwgthlcndeutgidaxnqv` (`fieldLayoutId`),
  KEY `idx_zjdgswhzimuywxhhhjupysdsspnwijaqrzeo` (`dateDeleted`),
  CONSTRAINT `fk_pnratdjdqymfjpjgbzxmisifsnikwvwvauxw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,'Home','home',NULL,'house',NULL,'{title}',1,'site',NULL,NULL,0,0,'site',NULL,0,'2026-06-12 09:09:30','2026-06-12 09:09:30',NULL,'3a15ea5a-e35f-4121-974b-8705a328441b'),(2,2,'JonSon','jonson',NULL,'user-vneck','cyan','{title}',1,'site',NULL,NULL,0,1,'site',NULL,0,'2026-06-16 10:28:02','2026-06-16 10:28:02',NULL,'64ce95c1-a716-4888-acc6-4e2127de1543'),(3,3,'Globals','globals',NULL,'gear-complex','cyan','{title}',0,'site',NULL,NULL,0,1,'site',NULL,1,'2026-06-16 10:34:15','2026-06-16 10:34:15',NULL,'440d7004-304c-41ed-8c66-fb158ab8b52c');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bxiaqihhgvppmakupleiygplmipcjggzbbpc` (`dateDeleted`),
  KEY `idx_jfvgtwwykxvbslavdcrnzxpjafwwqiihlvwv` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"d9efd81f-3c47-4a05-8d85-6ae573f921a3\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"a2f2bfc3-b3b3-4d20-82d0-b3a6c003a737\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2026-06-12T09:08:01+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"thumbFieldKey\": null, \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2026-06-12 09:09:30','2026-06-12 09:09:30',NULL,'f7bd572c-e534-4551-ae59-998e9755c111'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"69c4e482-9593-43ea-b490-cbc507ee6bff\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"ab6150fc-f230-4a9d-b45b-e0d4f7a4b16e\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2026-06-16T10:23:14+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"510a6afd-07bd-44de-a343-e2a1ba5c5cfc\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"e304270d-d9be-4623-8d5f-43901f7a8fa7\", \"required\": false, \"dateAdded\": \"2026-06-16T10:28:02+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"thumbFieldKey\": null, \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2026-06-16 10:28:02','2026-06-16 10:28:02',NULL,'5299ac0e-f8fb-407f-88ca-13d55d320395'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"2b7790d0-60e5-452e-ac3d-d1b0b88581b5\", \"name\": \"JonSon\", \"elements\": [{\"tip\": null, \"uid\": \"9002b8d4-9897-4b43-a340-42061a970bb8\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"e304270d-d9be-4623-8d5f-43901f7a8fa7\", \"required\": false, \"dateAdded\": \"2026-06-16T10:34:15+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"thumbFieldKey\": null, \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2026-06-16 10:34:15','2026-06-16 10:34:15',NULL,'a06da29c-8e3f-451e-beab-c0926e32126d');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wcddnwhilbhgvbgooqlubpkvfgibawkvdtjz` (`handle`,`context`),
  KEY `idx_oybrvcnhdklqgwfkdxjgipzjwgppbhalwiip` (`context`),
  KEY `idx_papgvbrsaogevtsikhcqzimxakupartxhnkh` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Personality','personality','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":true,\"initialRows\":8,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2026-06-16 10:27:55','2026-06-16 10:27:55',NULL,'e304270d-d9be-4623-8d5f-43901f7a8fa7');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_obdljwprleimdoodbykyfxwijvxcnlgiimid` (`name`),
  KEY `idx_pxpiahhuandniyymvxshapadtagqzovcaumj` (`handle`),
  KEY `idx_trzcagzknrhbyjyftmmphdqncigbbqesxoyc` (`fieldLayoutId`),
  KEY `idx_wukxndilozazvreiekgusetealycpacyslmx` (`sortOrder`),
  CONSTRAINT `fk_jrbgxsvqigguuirudmbvtwhyffmibkobqeuk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nsujdmginbvwxtybagjlidymffktderhfjet` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cwhwdnuciuxzncxwxeettkerktgshksgditz` (`accessToken`),
  UNIQUE KEY `idx_vgpseovpdwqifezadeojtgmxyycpdaaykhvy` (`name`),
  KEY `fk_rbraknstdmqmcrlgjihvmlugqmutbfttjqys` (`schemaId`),
  CONSTRAINT `fk_rbraknstdmqmcrlgjihvmlugqmutbfttjqys` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bnfdflcjsjfiwjxpqkogbngvufteawekluub` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jghlfkwvjjxsimiofjcwafizpdraeziukajy` (`name`),
  KEY `idx_piianxhyaipjadcjdooxzpuvnczocmfhlrjo` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.10.5','5.10.0.0',0,'dfttezthwbfs','3@sijokrpdme','2026-06-09 20:39:36','2026-06-16 10:34:36','79a51ce6-7719-4864-9309-caa76034e0aa');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hshdnwolknnwbzwsbovjmwqbsfqdqlvkseip` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','cd6853c9-77aa-4089-862a-f0c778f04fba'),(2,'craft','m221101_115859_create_entries_authors_table','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','c7084a66-09ab-4147-aafc-7e67ab3078c6'),(3,'craft','m221107_112121_add_max_authors_to_sections','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','1519069a-d55c-4d59-ac47-4eb277c48ba9'),(4,'craft','m221205_082005_translatable_asset_alt_text','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','243340a0-c184-47b9-8cc1-d036dac7ebc5'),(5,'craft','m230314_110309_add_authenticator_table','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','ea8e54d6-e818-4caf-9b66-59e94342e440'),(6,'craft','m230314_111234_add_webauthn_table','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','93e4bd3d-8801-4742-bc1a-ee6e6ea8bad2'),(7,'craft','m230503_120303_add_recoverycodes_table','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','216b922c-4736-4117-8137-d6bdb064078f'),(8,'craft','m230511_000000_field_layout_configs','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','f6ae65f0-31cf-4ac7-bdca-a6d12acd691b'),(9,'craft','m230511_215903_content_refactor','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','d4fe7fd3-502e-4eaf-9c18-bca153b36025'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','4af160f6-cc08-4378-a694-e097784d36c7'),(11,'craft','m230524_000001_entry_type_icons','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','f990186b-f4a9-4ca4-9b79-5d65f34d004a'),(12,'craft','m230524_000002_entry_type_colors','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','9346b317-4f1e-49e2-aa31-c5d5caceb740'),(13,'craft','m230524_220029_global_entry_types','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','1808e681-a562-4311-9e4b-933e6718d2d2'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','eac1ef8d-e1d9-45d6-b461-6de475e095c0'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','d37121d7-cbdf-4b96-8754-025af26d7454'),(16,'craft','m230616_173810_kill_field_groups','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','332b701f-1109-479b-9a6e-726a9a173236'),(17,'craft','m230616_183820_remove_field_name_limit','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','ae482139-68be-4e87-929b-63a1cef359fb'),(18,'craft','m230617_070415_entrify_matrix_blocks','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','1946ee06-25de-47cc-bb08-8cf09a5cecc5'),(19,'craft','m230710_162700_element_activity','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','bc0765a5-1c07-4585-8e77-15549e5c0290'),(20,'craft','m230820_162023_fix_cache_id_type','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','ad103cbe-510a-42e2-9e14-712755b6059c'),(21,'craft','m230826_094050_fix_session_id_type','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','3ba333f9-aec9-4477-821e-498932101a93'),(22,'craft','m230904_190356_address_fields','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','ca080379-5a43-416d-a889-c1f69ee148ab'),(23,'craft','m230928_144045_add_subpath_to_volumes','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','5c32a313-6a80-4aba-8afb-b3fbb20b9518'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','33b0d42b-dbd1-433a-8feb-474da6b31e0c'),(25,'craft','m231213_030600_element_bulk_ops','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','cfbee3b7-d43d-44f0-865c-0fc29d9b96bf'),(26,'craft','m240129_150719_sites_language_amend_length','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','e3b854f7-4954-4858-b4f8-b7ff0f58965c'),(27,'craft','m240206_035135_convert_json_columns','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','d08b32fb-dee2-4bfd-a489-3dba1909761b'),(28,'craft','m240207_182452_address_line_3','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','785ab678-0f7d-43ca-badd-8da0aca2422f'),(29,'craft','m240302_212719_solo_preview_targets','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','aa66b3ef-95de-4f3f-bddf-aabfcb871ab2'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','fa0ab0f0-500c-4755-bd88-1c96e2d1dc1e'),(31,'craft','m240723_214330_drop_bulkop_fk','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','c39900ac-881f-421f-abfa-e51f22eb60c9'),(32,'craft','m240731_053543_soft_delete_fields','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','af4c6486-4114-4a98-bd69-1676180819ce'),(33,'craft','m240805_154041_sso_identities','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','04ee965c-f449-424f-ae71-7ee78ae83f00'),(34,'craft','m240926_202248_track_entries_deleted_with_section','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','04eea1e3-497d-45a4-8a72-6b911b8d3075'),(35,'craft','m241120_190905_user_affiliated_sites','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','22ab1e01-64ec-4906-a0ea-5eec72f9f346'),(36,'craft','m241125_122914_add_viewUsers_permission','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','3829825d-648e-4bfe-b3e7-cf656961356a'),(37,'craft','m250119_135304_entry_type_overrides','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','6f638991-7335-4cdc-b13e-a6ed783afffa'),(38,'craft','m250206_135036_search_index_queue','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','c0ddb98b-d381-4acd-9947-cca9a7a3049e'),(39,'craft','m250207_172349_bulkop_events','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','36b5faa2-9bf8-4926-9587-3b12990b86a2'),(40,'craft','m250315_131608_unlimited_authors','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','4652d098-fe29-4c32-9f81-258776b5e220'),(41,'craft','m250403_171253_static_statuses','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','6361df04-7a4f-45b3-a738-7b85d5cb2b40'),(42,'craft','m250512_164202_asset_mime_types','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','2e4ae308-37ba-41d2-b91b-d0121c6fc360'),(43,'craft','m250522_090843_add_deleteEntriesForSite_and_deletePeerEntriesForSite_permissions','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','149baf1e-40d8-4273-8218-dc5f548f142b'),(44,'craft','m250531_183058_content_blocks','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','d31e7001-4277-4a26-bde8-a8c9b348d01a'),(45,'craft','m250623_105031_entry_type_descriptions','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','22d82464-39f0-4238-9950-f9579aa71aad'),(46,'craft','m250910_144630_add_elements_owners_sort_order_index','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','d285c91c-5310-4680-a4a2-a72ef2ce6127'),(47,'craft','m251030_203440_drop_widgets_enabled_column','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','7186a0ba-7a2e-4773-8f4d-4778bbe1e0ed'),(48,'craft','m251110_192405_entry_type_ui_label_formats','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','848deede-4acb-4c7a-81e1-9d860b6aac8c'),(49,'craft','m251205_190131_drop_searchindexqueue_fk','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','9206d7c3-4d27-4201-9444-c816cea0f02e'),(50,'craft','m251230_192239_update_field_layouts','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','793fa4a2-1e3d-4e7e-866b-6f462cf2b4c7'),(51,'craft','m260106_130629_directive_schema_components','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','0636e572-d644-49ce-8e9e-2d765b667166'),(52,'craft','m260120_120907_line_breaks_in_titles','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','10f6dd74-76e2-4288-b8ac-ff4b2e84c1d1'),(53,'craft','m260125_233614_changeAuthorForPeerEntries_permission','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','ff43728d-f814-4a3e-89f1-47faf8c07ca4'),(54,'craft','m260401_155236_min_authors_setting','2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-09 20:39:37','16f67fec-daec-4856-bbd6-6157017f3a5e');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_setpntlduaiidldaywwyngtgiuyaewezmvck` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'vite','5.0.1','1.0.0','2026-06-10 17:48:07','2026-06-10 17:48:07','2026-06-10 17:48:07','cc542051-297f-4415-afd3-3404db7bb968');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1781606075'),('email.fromEmail','\"j@leverrier.co.uk\"'),('email.fromName','\"Jon Leverrier\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.allowLineBreaksInTitles','false'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.color','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.description','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.cardThumbAlignment','\"end\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elementCondition','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.autocapitalize','true'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.autocomplete','false'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.autocorrect','true'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.class','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.dateAdded','\"2026-06-12T09:08:01+00:00\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.disabled','false'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.elementCondition','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.id','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.inputType','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.instructions','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.label','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.max','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.min','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.name','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.orientation','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.placeholder','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.readonly','false'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.required','true'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.size','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.step','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.tip','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.title','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.uid','\"a2f2bfc3-b3b3-4d20-82d0-b3a6c003a737\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.userCondition','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.warning','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.elements.0.width','100'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.name','\"Content\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.uid','\"d9efd81f-3c47-4a05-8d85-6ae573f921a3\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.tabs.0.userCondition','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.fieldLayouts.f7bd572c-e534-4551-ae59-998e9755c111.thumbFieldKey','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.handle','\"home\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.hasTitleField','true'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.icon','\"house\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.name','\"Home\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.showSlugField','false'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.showStatusField','false'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.slugTranslationKeyFormat','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.slugTranslationMethod','\"site\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.titleFormat','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.titleTranslationKeyFormat','null'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.titleTranslationMethod','\"site\"'),('entryTypes.3a15ea5a-e35f-4121-974b-8705a328441b.uiLabelFormat','\"{title}\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.allowLineBreaksInTitles','false'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.color','\"cyan\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.description','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.cardThumbAlignment','\"end\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elementCondition','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.dateAdded','\"2026-06-16T10:34:15+00:00\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.editCondition','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.elementCondition','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.elementEditCondition','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.fieldUid','\"e304270d-d9be-4623-8d5f-43901f7a8fa7\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.handle','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.instructions','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.label','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.required','false'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.tip','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.uid','\"9002b8d4-9897-4b43-a340-42061a970bb8\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.userCondition','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.warning','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.elements.0.width','100'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.name','\"JonSon\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.uid','\"2b7790d0-60e5-452e-ac3d-d1b0b88581b5\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.tabs.0.userCondition','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.fieldLayouts.a06da29c-8e3f-451e-beab-c0926e32126d.thumbFieldKey','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.handle','\"globals\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.hasTitleField','false'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.icon','\"gear-complex\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.name','\"Globals\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.showSlugField','true'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.showStatusField','true'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.slugTranslationKeyFormat','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.slugTranslationMethod','\"site\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.titleFormat','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.titleTranslationKeyFormat','null'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.titleTranslationMethod','\"site\"'),('entryTypes.440d7004-304c-41ed-8c66-fb158ab8b52c.uiLabelFormat','\"{title}\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.allowLineBreaksInTitles','false'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.color','\"cyan\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.description','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.cardThumbAlignment','\"end\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elementCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.autocapitalize','true'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.autocomplete','false'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.autocorrect','true'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.class','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.dateAdded','\"2026-06-16T10:23:14+00:00\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.disabled','false'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.elementCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.id','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.inputType','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.instructions','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.label','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.max','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.min','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.name','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.orientation','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.placeholder','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.readonly','false'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.required','true'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.size','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.step','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.tip','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.title','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.uid','\"ab6150fc-f230-4a9d-b45b-e0d4f7a4b16e\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.userCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.warning','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.0.width','100'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.dateAdded','\"2026-06-16T10:28:02+00:00\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.editCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.elementCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.elementEditCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.fieldUid','\"e304270d-d9be-4623-8d5f-43901f7a8fa7\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.handle','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.instructions','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.label','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.required','false'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.tip','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.uid','\"510a6afd-07bd-44de-a343-e2a1ba5c5cfc\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.userCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.warning','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.elements.1.width','100'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.name','\"Content\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.uid','\"69c4e482-9593-43ea-b490-cbc507ee6bff\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.tabs.0.userCondition','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.fieldLayouts.5299ac0e-f8fb-407f-88ca-13d55d320395.thumbFieldKey','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.handle','\"jonson\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.hasTitleField','true'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.icon','\"user-vneck\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.name','\"JonSon\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.showSlugField','true'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.showStatusField','false'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.slugTranslationKeyFormat','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.slugTranslationMethod','\"site\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.titleFormat','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.titleTranslationKeyFormat','null'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.titleTranslationMethod','\"site\"'),('entryTypes.64ce95c1-a716-4888-acc6-4e2127de1543.uiLabelFormat','\"{title}\"'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.columnSuffix','null'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.handle','\"personality\"'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.instructions','null'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.name','\"Personality\"'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.searchable','false'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.settings.byteLimit','null'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.settings.charLimit','null'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.settings.code','true'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.settings.initialRows','8'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.settings.multiline','true'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.settings.placeholder','null'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.settings.uiMode','\"normal\"'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.translationKeyFormat','null'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.translationMethod','\"none\"'),('fields.e304270d-d9be-4623-8d5f-43901f7a8fa7.type','\"craft\\\\fields\\\\PlainText\"'),('meta.__names__.088f037b-ae75-4bd5-9398-7cc9651e7475','\"Jon Leverrier\"'),('meta.__names__.3a15ea5a-e35f-4121-974b-8705a328441b','\"Home\"'),('meta.__names__.440d7004-304c-41ed-8c66-fb158ab8b52c','\"Globals\"'),('meta.__names__.5a671f63-dc27-42cc-a745-2cfca5c54f6a','\"Globals\"'),('meta.__names__.64ce95c1-a716-4888-acc6-4e2127de1543','\"JonSon\"'),('meta.__names__.6a0c33fd-98e1-48b8-a4d0-24e7132d1623','\"Jon Leverrier\"'),('meta.__names__.e304270d-d9be-4623-8d5f-43901f7a8fa7','\"Personality\"'),('meta.__names__.f72fde96-d0e8-4526-bd7e-52228d6dc2b7','\"Home\"'),('plugins.vite.edition','\"standard\"'),('plugins.vite.enabled','true'),('plugins.vite.schemaVersion','\"1.0.0\"'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.defaultPlacement','\"end\"'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.enableVersioning','true'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.entryTypes.0.uid','\"440d7004-304c-41ed-8c66-fb158ab8b52c\"'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.handle','\"globals\"'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.maxAuthors','1'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.minAuthors','1'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.name','\"Globals\"'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.propagationMethod','\"all\"'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.enabledByDefault','true'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.hasUrls','false'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.template','null'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.uriFormat','null'),('sections.5a671f63-dc27-42cc-a745-2cfca5c54f6a.type','\"single\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.defaultPlacement','\"end\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.enableVersioning','true'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.entryTypes.0.uid','\"3a15ea5a-e35f-4121-974b-8705a328441b\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.handle','\"homepage\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.maxAuthors','1'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.minAuthors','1'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.name','\"Home\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.previewTargets.0.label','\"Primary entry page\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.previewTargets.0.refresh','\"1\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.previewTargets.0.urlFormat','\"{url}\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.propagationMethod','\"all\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.enabledByDefault','true'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.hasUrls','true'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.template','\"_routers/single.twig\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.siteSettings.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.uriFormat','\"__home__\"'),('sections.f72fde96-d0e8-4526-bd7e-52228d6dc2b7.type','\"single\"'),('siteGroups.088f037b-ae75-4bd5-9398-7cc9651e7475.name','\"Jon Leverrier\"'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.handle','\"default\"'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.hasUrls','true'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.language','\"en-JE\"'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.name','\"Jon Leverrier\"'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.primary','true'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.siteGroup','\"088f037b-ae75-4bd5-9398-7cc9651e7475\"'),('sites.6a0c33fd-98e1-48b8-a4d0-24e7132d1623.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Jon Leverrier\"'),('system.schemaVersion','\"5.10.0.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_hxtuklpjdoodlzizpmmiljjbnzrenuukiwbi` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_ptdzsqmeikmosoimxkldjuqsgkljynmgksko` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tpqezegapdqqtwpgeokqunqjmkedjapdmocd` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ycegvmefbsokcpzcqyxbhhrwfhskphczdwvv` (`sourceId`),
  KEY `idx_laijdeyewoiblcjvqlomvkjfamdxbxqtnhgd` (`targetId`),
  KEY `idx_xawlivmtzbjwhjvxwaocaczhenhnmxljbram` (`sourceSiteId`),
  CONSTRAINT `fk_ovlpdmthylfigtldcwebswrmrmhrwnjckmbx` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tldoahmnzadyyzjjsbbmwkgyohmroqinnacb` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wecuqzeqtwfrxdufrezlprtbojhjapiqfmjt` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('108d5f6','@craft/web/assets/xregexp/dist'),('337cb09f','@craft/web/assets/velocity/dist'),('36b86d4a','@craft/web/assets/jquerytouchevents/dist'),('36ebb228','@craft/web/assets/jquerypayment/dist'),('38e03bef','@craft/web/assets/datepickeri18n/dist'),('5f7cd2e0','@craft/web/assets/animationblocker/dist'),('604519e0','@bower/jquery/dist'),('6aa289f6','@craft/web/assets/jqueryui/dist'),('74d95f5d','@craft/web/assets/fileupload/dist'),('828f230c','@craft/web/assets/axios/dist'),('a48b0be3','@craft/web/assets/d3/dist'),('ab068f6','@craft/web/assets/picturefill/dist'),('ac4857e6','@craft/web/assets/theme/dist'),('afea0254','@craft/web/assets/iframeresizer/dist'),('b2f68fe2','@craft/web/assets/selectize/dist'),('b5e335c0','@craft/web/assets/tailwindreset/dist'),('bebe2daa','@craft/web/assets/cp/dist'),('dcd4b449','@craft/web/assets/garnish/dist'),('f466835e','@craft/web/assets/fabric/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yullmfbcuxkpxxrflfapzujlvdhvdxevlqza` (`canonicalId`,`num`),
  KEY `fk_ojvbwahcsmycpzizkhjtcuhtyswkkmjktaru` (`creatorId`),
  CONSTRAINT `fk_ojvbwahcsmycpzizkhjtcuhtyswkkmjktaru` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pnfxcvgjikqkooplfdzeayrysqwcfxnanavz` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,5,1,1,NULL),(3,5,1,2,NULL),(4,5,1,3,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_csgxxzjxvlxnhzqqptppcqwjflkgksxngeej` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' j leverrier co uk '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' jonleverrier '),(2,'slug',0,1,' home '),(2,'title',0,1,' home '),(4,'slug',0,1,' temp mtdkmetkkodpuspyhnyoxpapdvypamkxfwjy '),(4,'title',0,1,''),(5,'slug',0,1,' globals '),(5,'title',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jynoclxwealjbhqzghtoemaorfwdzfngmnbf` (`elementId`,`siteId`,`reserved`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_vwxvztxyvrbmwdmrfnhwtlmhbjpyfqkftimz` (`jobId`,`fieldHandle`),
  CONSTRAINT `fk_snywfhztqtfblbxagyjmkafullmgkgwcohgo` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `minAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qqmzgcojyervljolfgkijhzgaddcdvlrfrdo` (`handle`),
  KEY `idx_icnxxxkihlimdcjkwnfbxesfquhesyjrsqjr` (`name`),
  KEY `idx_rnhmtxuzcmkibxscrjchsojyguqrcunforxa` (`structureId`),
  KEY `idx_xfxaojujuzybxrdktlhygbiokcqoaospqnnv` (`dateDeleted`),
  CONSTRAINT `fk_ijedfafnaubcwhzxoazgbhsustimevjrcawt` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Home','homepage','single',1,1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2026-06-12 09:09:34','2026-06-12 09:09:34',NULL,'f72fde96-d0e8-4526-bd7e-52228d6dc2b7'),(2,NULL,'Globals','globals','single',1,1,1,'all','end',NULL,'2026-06-16 10:28:43','2026-06-16 10:34:35',NULL,'5a671f63-dc27-42cc-a745-2cfca5c54f6a');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_jdmnjswnkudzrqwdgibkliahyuwlzbybkhip` (`typeId`),
  CONSTRAINT `fk_fvxjrlbhmeeqmfjemxmqfpwhgfthrdnftmrl` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jdmnjswnkudzrqwdgibkliahyuwlzbybkhip` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1,NULL,NULL,NULL),(2,3,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ylpmuspsexccpopxyjdrldnguzryxjmwavqm` (`sectionId`,`siteId`),
  KEY `idx_zrltfteiupsdfhkvzmyrpvzcayfthcvxpvic` (`siteId`),
  CONSTRAINT `fk_wdgemvqoiqrgbcedvedkpslbpmkrmyslttgv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zkfzpzoehgoypvhzctyeprsbidsaplhkclxt` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','_routers/single.twig',1,'2026-06-12 09:09:34','2026-06-12 09:09:34','8e5a7a50-25bc-47a6-811e-aeded2d410e6'),(2,2,1,0,NULL,NULL,1,'2026-06-16 10:28:43','2026-06-16 10:28:43','6fc8e67d-bd98-419d-9a65-5ac16a671b41');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bgpyjogxbszgqhoylmpfgvvlhsecvojjoipm` (`uid`),
  KEY `idx_psfpbnxgkfditmcfqcbhsdqubtpcxsncebrb` (`token`),
  KEY `idx_frjfijsrmgkyjczgetnkznlpvrxpedjvqnma` (`dateUpdated`),
  KEY `idx_sdoqheapebeemfilnuipmkeoxbwqkpbcziea` (`userId`),
  CONSTRAINT `fk_qrqtndohucasfqzsbjpvvglfkiaelyjtokki` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zjnopuqwnnqjibhdygcftwdthsftdmwlfyqv` (`userId`,`message`),
  CONSTRAINT `fk_dypkkidylslwcljwbvjvtsfdekqpjjmvquoh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aotlnrvhmjaebxcwwmtqkjkpbxfylirkcjuo` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Jon Leverrier','2026-06-09 20:39:36','2026-06-09 20:39:36',NULL,'088f037b-ae75-4bd5-9398-7cc9651e7475');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ebqysavsluhtosbaqddmathjdfiireobyhmw` (`dateDeleted`),
  KEY `idx_sxzwgnyfptvdtmlupxqrjghkjvvrjzgqjnkc` (`handle`),
  KEY `idx_ckwuopqogtgqxaxcepnwopvrijpplupbcqli` (`sortOrder`),
  KEY `fk_fdwghmbxcpsopfkqmryalnxijegleedhkpou` (`groupId`),
  CONSTRAINT `fk_fdwghmbxcpsopfkqmryalnxijegleedhkpou` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Jon Leverrier','default','en-JE',1,'$PRIMARY_SITE_URL',1,'2026-06-09 20:39:36','2026-06-09 20:39:36',NULL,'6a0c33fd-98e1-48b8-a4d0-24e7132d1623');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_zlztkrejobsnuuvfmxadnewovgoxhvllnubw` (`userId`),
  CONSTRAINT `fk_zlztkrejobsnuuvfmxadnewovgoxhvllnubw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yorwogyharlyuhrvwvuajcitunrngvcutwgu` (`structureId`,`elementId`),
  KEY `idx_xxzzutttgwqqrynmzdbxixohwysjfohwsaow` (`root`),
  KEY `idx_httsojnwpzcujbfzlaevzxkjbpcrygzdutbc` (`lft`),
  KEY `idx_pmtnpqaqriykuquzhcbhyshyqxbfzrzdheir` (`rgt`),
  KEY `idx_wbokvfqznmpbpalkkyxtzgitlyodjskjpigd` (`level`),
  KEY `idx_kobjhowkqsuihwshzhvitjkdhoizsqmnayyu` (`elementId`),
  CONSTRAINT `fk_tezhyomijhttujqmzmoqxkqvvnrjsnhzetbk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,2,0,'2026-06-16 10:28:50','2026-06-16 10:34:58','9ffeea10-f230-4f72-a725-36ea936ccc29');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oaudvfzawwvfwjhhgymrbdyminnapnudofcv` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,1,'2026-06-16 10:28:43','2026-06-16 10:28:43','2026-06-16 10:34:35','6814c7f3-928f-4706-8328-7cfa7f635052');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_idprolicluoodxvgaltbsgeezeaigdyifajo` (`key`,`language`),
  KEY `idx_nqfuwgacvuxjdbpllfirwhffpebozdopvpiv` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xecnbohcrpmguemlzjtmnemhugytggcrexah` (`name`),
  KEY `idx_htrvoyrmllodgkimdcoqpgucymzcqgzsugtx` (`handle`),
  KEY `idx_cesuzttbudxlhuaqvtanfptiedurtalfxbhe` (`dateDeleted`),
  KEY `fk_musbltvcnghunjzdynyxahhwkzeonetufmxk` (`fieldLayoutId`),
  CONSTRAINT `fk_musbltvcnghunjzdynyxahhwkzeonetufmxk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lfwphrbrajvckedsoaxbqootyjdqmmhyfgen` (`groupId`),
  CONSTRAINT `fk_rihaxyopcdanfbfxlmcuofddtqyziqskhzmn` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rvdnmupqjngrgrzscgqqfyvveibpwtnzelhm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tcdrdrvfaiolqujdxncigyvolkgpcglmaekl` (`token`),
  KEY `idx_aaeulcnqgxvnxegcwxvtwwtxmgvgemrscmdl` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oouxgalrbpoecptkojgutugbujxievustulv` (`handle`),
  KEY `idx_kgibmmfsmphjghgkbxqttcnnixnrueizoybs` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gvzqfcualjinnmjmwrfadobqthstxdkwczhs` (`groupId`,`userId`),
  KEY `idx_hjezyetqlambdddcsawowmjdrfttfddznuzz` (`userId`),
  CONSTRAINT `fk_kqkqkjwzcgbzfolzbiswnrgdjfdlatcqtznc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sxdfddbxuiwdaiuzzyuqhykdtsgypeacnpqn` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ooobqdndjmkdeauyarvzyyzwngylfafulyys` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qdoyjsyzwnnkquvulwwheldljcjguchzwbxl` (`permissionId`,`groupId`),
  KEY `idx_unukvqoftykrawkvdczfhopwkveikfqebtez` (`groupId`),
  CONSTRAINT `fk_wqxfmqvwniujwuspxcmhyjfczwhhbxeuojea` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xvscssvtsizlbsqnoaactrekstumkqszbrcr` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xuxhikmyuumywulrybjiapsdiopxevjstndt` (`permissionId`,`userId`),
  KEY `idx_ftcdynzdbtjizbouwltsylqmkorascovdpft` (`userId`),
  CONSTRAINT `fk_tmeigzgfqlorbectmihosuclgkonxcciofbw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tzlefnkiozaokqemcsdxxfbemxtxwruyvtjw` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_ajlhhqrekcuempifdyoqbtasifcxqyvqheat` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en-JE\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dkuzrkjuemkubkqtmdtppztzpeabvmbzdulp` (`active`),
  KEY `idx_xdsqsdynchxrsvtossdkzuklztqkjcylzfco` (`locked`),
  KEY `idx_ijgsniglhhefbcwdklkziihzegvilrgklsnh` (`pending`),
  KEY `idx_bvebyrmafakdtvupnnqeadipjsycmywepzwu` (`suspended`),
  KEY `idx_fvvyzbpemrdfxctepiczmzmmlqickjttiybp` (`verificationCode`),
  KEY `idx_jecnvnrcgiynlgbyhjxohbyxpduhxoykamzw` (`email`),
  KEY `idx_wpyrsytbfjenpxdcfyzyaadjlzluzsapswvx` (`username`),
  KEY `fk_xhyasfoikanhlsbcnuamgabmdxbfrnotagzv` (`photoId`),
  KEY `fk_rbikyqhmjtgiaazcuyxxroeetqvxqdpvdgpe` (`affiliatedSiteId`),
  CONSTRAINT `fk_rbikyqhmjtgiaazcuyxxroeetqvxqdpvdgpe` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_synjiistzzgmxcpipfmjvbzpogfkgarcfhqg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xhyasfoikanhlsbcnuamgabmdxbfrnotagzv` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'jonleverrier',NULL,NULL,NULL,'j@leverrier.co.uk','$2y$13$x4frU7ywTkfZD77pBZFBSeICqHcC1dwNAAcpBWyZmsoRF506jrfMm','2026-06-16 10:16:53',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2026-06-09 20:39:37','2026-06-09 20:39:37','2026-06-16 10:16:53');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fuaiqverbdkqzdmhfxdwwhfzwtdqqrmusgsz` (`name`,`parentId`,`volumeId`),
  KEY `idx_gwqgdatucrhsepxxtgjmmuyzbgcjzqhdfpyt` (`parentId`),
  KEY `idx_vfygabtnqczqrgbxssoxfvvyelotmotvadud` (`volumeId`),
  CONSTRAINT `fk_icviiupftuyfmqhmfshauteevssjjlnsyknu` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_udcuemxsqvgmosufpeasrmtbmtrkkedlspak` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zpudoxmhhtsxvynjcttjygmdftzxojxlkiba` (`name`),
  KEY `idx_msjykulonrarhxlmutfkrkknddgsqqocmzuj` (`handle`),
  KEY `idx_xxdgxdxantvprnssuhreqnksaggejvwzsild` (`fieldLayoutId`),
  KEY `idx_ibysrfsfnswcyumsrdnvdinqsnnbfyedsurz` (`dateDeleted`),
  CONSTRAINT `fk_iyaaxfzpsxtyvhhhjftzcnwvsogxgpgbzwoi` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_mhywmntgrrpsioactyhangfxywohyryhucbk` (`userId`),
  CONSTRAINT `fk_mhywmntgrrpsioactyhangfxywohyryhucbk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bgaxplstbfaisgvfvnslfuoedtaxiixsffdz` (`userId`),
  CONSTRAINT `fk_atcwagxhqipvseeydybjoqglkvqwhitsbluu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}','2026-06-09 20:39:55','2026-06-09 20:39:55','62a6c54e-319e-402c-97db-0e4d707e8b86'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]','2026-06-09 20:39:55','2026-06-09 20:39:55','48e9f100-1871-4c6d-a0d4-8964beb47d2e'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]','2026-06-09 20:39:55','2026-06-09 20:39:55','8b4e8733-62a9-4687-aba4-91aebbc1d80a'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}','2026-06-09 20:39:55','2026-06-09 20:39:55','ef1db559-e36c-4e96-8f3b-640736b23357');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-17 18:06:14
